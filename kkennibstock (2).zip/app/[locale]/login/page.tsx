'use client'
import React from 'react';
import { useState } from "react";
import { useRouter  } from 'next/navigation';
import { UserService } from '@/services/UserService';
import Image from 'next/image';
import { useLocale } from '@/layouts/LocaleContext';
import { GoogleOAuthProvider, GoogleLogin } from '@react-oauth/google';
import { fetchPostWithCookie, fetchHappGet, fetchHappPost } from '@/repositories/req'

const LoginPage = () => {
  
  const locale = useLocale();  
  const [t, setT] = useState<any>();

  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [selectedLocale, setSelectedLocale] = useState(locale);
  const [loading, setLoading] = useState(false);

  const router = useRouter();
  const loginUser = async (e: any) => {
    e.preventDefault();

    const serv = new UserService();
    const result: any = await serv.login(userId, password);
    if (result) {
      setLoading(true);
      const isAdmin = localStorage.getItem("isAdmin") === 'Y';
      router.push(`/${locale}/${isAdmin ? 'adm/user_list' : 'ops/stat_fwh'}`); 
    } else {
      alert("입력하신 아이디 또는 비밀번호를 확인해주세요.");
    }
  };

  const moveSignUp = async (e: any) => {
    e.preventDefault();
    router.push(`/${selectedLocale}/signup`); 
  };

  const moveFindAcc = async (e: any) => {
    e.preventDefault();
    window.open(`/${locale}/find_acc`, '_blank'); // 새 탭에서 열기
  }

  const handleKeyDown = (e: any) => {
    if (e.key === "Enter") {
      loginUser(e);
    }
  };

  const loginGoogle = async (credential: string) => {
    const result = await fetchPostWithCookie("api/auth/google", credential)

    console.log("loginGoogle Result");
    console.log(result);
  }

  return (
    <div className="min-h-screen mt-[15%]">
    {
      loading ?
      (<div>Loading...</div>) :
      (
      <div className='mt-14'>
        <div className='flex justify-center items-center'>
          <Image width={220} height={100} className="logo" src="/images/logo/corp_logo_with_name.svg" alt="Logo" />
        </div>
        <div className="flex justify-center mt-10 w-full">
          <div className="w-full p-6">
            <input
              className="w-full mb-3"
              type="text"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              placeholder='Enter your account...'
              onKeyDown={handleKeyDown} // 엔터 키 이벤트 추가
              required
            />
          
            <input
              className="w-full mb-4"
              type="password" 
              value={password}
              placeholder='Enter your password...'
              onKeyDown={handleKeyDown} // 엔터 키 이벤트 추가
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            
            <div>
              <button className="btn-main w-full h-[45px] font-bold text-[1.2rem] tracking-wider" onClick={loginUser}>Login</button>
            </div>
                                
            <div className='flex items-center mt-14 p-1'>
              <div className='text-[0.8rem]'>Don’t you have an account?</div>
              <button className="btn-link text-[0.9rem] ms-2" onClick={moveSignUp}>SignUp</button>                
            </div>
              
            <div className='flex items-center mt-2 p-1'>
              <div className='text-[0.8rem]'>Forgot your account?</div>                
              <div className="btn-link text-[0.9rem] ms-2" onClick={moveFindAcc}>Find you account</div>
            </div>              

            <div>

    <GoogleOAuthProvider clientId={process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID ?? ''}>
      <GoogleLogin
        onSuccess={response => {
          if (!response || !response.credential)
            return;
          console.log(response.credential)
          loginGoogle(response.credential ?? '');

        }}
        onError={() => {
          console.log('Login Failed');
        }}
      />
    </GoogleOAuthProvider>

              
            </div>
          </div>
        </div>
      </div>      
      )
    }

    </div>    
  );
}

export default LoginPage;