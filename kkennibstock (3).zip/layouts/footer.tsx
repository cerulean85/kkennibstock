const CommonFooter = () => {
    return (
        <footer>
            <div className="footer-container">
                &copy; 2025. ZHkim All Rights Reserved.
            </div>
        </footer>
    )
}

export default CommonFooter;