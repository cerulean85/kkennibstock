'use client';
import { ReactNode } from 'react';;
export default function CommonMain({ children }: { children: ReactNode }) {

  return (

			{children}

	)
}
